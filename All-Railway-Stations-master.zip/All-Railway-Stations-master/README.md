# All-Railway-Stations
Visualizing all the Railway Stations in India

Interactive Visualization Link: https://namastevis.github.io/All-Railway-Stations/

We have plotted 8495 Indian Railway Stations on a map. One can view the stations category wise. ALso on hovering over the stations, one can see all the details (in a GeoJSON format) on the right.
